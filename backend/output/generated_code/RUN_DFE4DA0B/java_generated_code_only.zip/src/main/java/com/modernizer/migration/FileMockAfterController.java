package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotation.Entity;
import io.quarkus.hibernate.orm.annotation.Id;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FileMockAfterController {

    @Id
    private String utTestCaseName;

    public void readInputFileError() {
        // TO DO: implement readInputFileError method
    }

    public void fileNotFound() {
        // TO DO: implement fileNotFound method
    }

    public void fileNotOpenError() {
        // TO DO: implement fileNotOpenError method
    }

    public void fileOpenError() {
        // TO DO: implement fileOpenError method
    }

    public void fileReadError() {
        // TO DO: implement fileReadError method
    }
}
package com.modernizer.migration;

public class AdapterStub {

    public HttpResponse handleExpectStatements() {
        // TO DO: implement stub for EXPECT statements
        return HttpResponse.ok().build();
    }
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class OutField3Service {

    @Column(name = "OUT-FIELD-3", length = 14)
    private String outField3;

    public Optional<String> getOutField3() {
        return Optional.ofNullable(outField3);
    }

    public void setOutField3(String outField3) {
        this.outField3 = outField3;
    }
}

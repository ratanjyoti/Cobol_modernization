package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CallMockAfterService {

    @Id
    private String wsAlpha;
    private String wsOmega;

    public void basicCall() {
        // TO DO: implement basic call logic
    }

    public void classicCall() {
        // TO DO: implement classic call logic
    }

    public void dynamicCall() {
        // TO DO: implement dynamic call logic
    }

    public void end() {
        // TO DO: implement end logic
    }

    public void utAfter() {
        // TO DO: implement ut after logic
    }

    public void utBefore() {
        // TO DO: implement ut before logic
    }

    public void utEnd() {
        // TO DO: implement ut end logic
    }

    public void utInitialize() {
        // TO DO: implement ut initialize logic
    }
}
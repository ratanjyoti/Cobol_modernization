package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UtMockAfterService {

    @Id
    private String wsAlpha;
    private String wsOmega;

    public void utAfter() {
        // TO DO: implement ut after logic
    }

    public void utBefore() {
        // TO DO: implement ut before logic
    }

    public void utEnd() {
        // TO DO: implement ut end logic
    }

    public void utInitialize() {
        // TO DO: implement ut initialize logic
    }
}
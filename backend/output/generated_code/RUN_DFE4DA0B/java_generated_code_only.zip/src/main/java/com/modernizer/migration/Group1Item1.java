package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.math.BigDecimal;

@Entity
public class Group1Item1 {

    @Column(name = "GROUP-1")
    private BigDecimal group1;

    public BigDecimal getGroup1() {
        return group1;
    }

    public void setGroup1(BigDecimal group1) {
        this.group1 = group1;
    }
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import java.util.Optional;

@Entity
public class Group1Item1Item12 {

    private String item11_2;

    public Group1Item1Item12() {}

    public Optional<String> getItem11_2() {
        return Optional.ofNullable(item11_2);
    }

    public void setItem11_2(String item11_2) {
        this.item11_2 = item11_2;
    }
}
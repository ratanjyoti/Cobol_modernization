package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import java.util.Optional;

@Entity
public class Group1Item1Item11 {

    private String item11_1;

    public Group1Item1Item11() {}

    public Optional<String> getItem11_1() {
        return Optional.ofNullable(item11_1);
    }

    public void setItem11_1(String item11_1) {
        this.item11_1 = item11_1;
    }
}
package com.modernizer.migration.ConvertTestAfterService;

import io.quarkus.hibernate.orm.annotation.Entity;
import io.quarkus.hibernate.orm.annotation.Id;
import java.util.List;

@Entity
public class ConvertTestAfterService {

    @Id
    private String expectedResultFilename;

    private List<String> args;

    public void initialize(String[] args) {
        this.args = Arrays.asList(args);
    }

    public void compareFiles() {
        // TO DO: implement file comparison logic
    }

    public void compareRecords() {
        // TO DO: implement record comparison logic
    }
}

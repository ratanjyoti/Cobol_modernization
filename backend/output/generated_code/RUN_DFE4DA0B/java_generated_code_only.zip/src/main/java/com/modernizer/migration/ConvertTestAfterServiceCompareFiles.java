package com.modernizer.migration.ConvertTestAfterService;

import io.quarkus.hibernate.orm.annotation.Entity;
import io.quarkus.hibernate.orm.annotation.Id;
import java.util.List;

@Entity
public class ConvertTestAfterServiceCompareFiles {

    @Id
    private String expectedResultFilename;

    public void compareFiles() {
        // TO DO: implement file comparison logic
    }
}

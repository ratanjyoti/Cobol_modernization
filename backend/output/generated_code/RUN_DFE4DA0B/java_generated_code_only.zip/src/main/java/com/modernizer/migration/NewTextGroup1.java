package com.modernizer.migration;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Optional;

public class NewTextGroup1 {
    @Inject
    private Optional<String> optionalString;

    public String newTextGroup1() {
        return optionalString.orElse("Default value");
    }
}
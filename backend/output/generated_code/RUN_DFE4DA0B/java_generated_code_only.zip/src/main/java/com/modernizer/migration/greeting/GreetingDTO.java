package com.modernizer.migration.greeting;

public class GreetingDTO {

    private String wsFriend;
    private String messageIsGreeting;
    private String messageIsFarewell;
    private String messageIsFarewellLong;

    public GreetingDTO(String wsFriend, String messageIsGreeting, String messageIsFarewell, String messageIsFarewellLong) {
        this.wsFriend = wsFriend;
        this.messageIsGreeting = messageIsGreeting;
        this.messageIsFarewell = messageIsFarewell;
        this.messageIsFarewellLong = messageIsFarewellLong;
    }

    public String getWsFriend() {
        return wsFriend;
    }

    public void setWsFriend(String wsFriend) {
        this.wsFriend = wsFriend;
    }

    public String getMessageIsGreeting() {
        return messageIsGreeting;
    }

    public void setMessageIsGreeting(String messageIsGreeting) {
        this.messageIsGreeting = messageIsGreeting;
    }

    public String getMessageIsFarewell() {
        return messageIsFarewell;
    }

    public void setMessageIsFarewell(String messageIsFarewell) {
        this.messageIsFarewell = messageIsFarewell;
    }

    public String getMessageIsFarewellLong() {
        return messageIsFarewellLong;
    }

    public void setMessageIsFarewellLong(String messageIsFarewellLong) {
        this.messageIsFarewellLong = messageIsFarewellLong;
    }
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotation.Entity;
import io.quarkus.hibernate.orm.annotation.Id;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class FileMockAfterRepository {

    @Id
    private String utTestCaseName;

    public void utBefore() {
        // TO DO: implement utBefore method
    }

    public void utAfter() {
        // TO DO: implement utAfter method
    }

    public void utInitialize() {
        // TO DO: implement utInitialize method
    }

    public void end() {
        // TO DO: implement end method
    }
}
package com.modernizer.migration;

public class AlphaDomainModel {

    private String wsDisplayNumeric;
    private List<AlphaTable1> wsTable1;
    private List<AlphaTable2> wsTable2;

    public AlphaDomainModel(String wsDisplayNumeric) {
        this.wsDisplayNumeric = wsDisplayNumeric;
    }

    public String getWsDisplayNumeric() {
        return wsDisplayNumeric;
    }

    public void setWsDisplayNumeric(String wsDisplayNumeric) {
        this.wsDisplayNumeric = wsDisplayNumeric;
    }
}

package com.modernizer.migration.Replace3Service;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import java.util.Optional;

@Path("/replace3")
public class Replace3Service {

    @Inject
    private UtGamma utGamma;

    @Inject
    private UtOmega utOmega;

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String dynamicCall(@QueryParam("wsAlpha") String wsAlpha, @QueryParam("wsOmega") String wsOmega) {
        // Migrated from: REPLACE3.CBL::{3000-DYNAMIC-CALL}
        if (wsAlpha.equals("A") && wsOmega.equals("Z")) {
            return "B";
        } else if (wsAlpha.equals("A") && wsOmega.equals("Y")) {
            return "C";
        }
        // Migrated from: REPLACE3.CBL::{3001-DYNAMIC-CALL}
        return "D";
    }

    @POST
    public void end() {
        // Migrated from: REPLACE3.CBL::{9999-END}
    }
}
package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import java.util.Optional;

@Entity
public class Group1Item2Item21 {

    private String item21_1;

    public Group1Item2Item21() {}

    public Optional<String> getItem21_1() {
        return Optional.ofNullable(item21_1);
    }

    public void setItem21_1(String item21_1) {
        this.item21_1 = item21_1;
    }
}
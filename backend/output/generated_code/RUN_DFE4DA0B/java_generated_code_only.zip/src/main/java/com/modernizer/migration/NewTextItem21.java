package com.modernizer.migration;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Optional;

public class NewTextItem21 {
    @Inject
    private Optional<String> optionalString;

    public String newTextItem21() {
        return optionalString.orElse("Default value");
    }
}
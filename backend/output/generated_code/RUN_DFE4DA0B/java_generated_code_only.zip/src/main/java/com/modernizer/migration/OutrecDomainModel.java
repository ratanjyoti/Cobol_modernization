package com.modernizer.migration;

public class OutrecDomainModel {

    private String outField1;

    public OutrecDomainModel(String outField1) {
        this.outField1 = outField1;
    }

    // Migrated from: OUTREC.CBL:05 OUT-FIELD-1 PIC X(5).
    public String getOutField1() {
        return outField1;
    }
}

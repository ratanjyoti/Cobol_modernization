package com.modernizer.migration.Replace3Service;

public class UtOmega {
    private String utOmega;

    public UtOmega() {
        this.utOmega = "Omega";
    }

    public String getUtOmega() {
        return utOmega;
    }
}
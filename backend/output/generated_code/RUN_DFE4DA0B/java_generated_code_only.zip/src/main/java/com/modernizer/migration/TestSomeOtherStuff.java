package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class TestSomeOtherStuff {

    @Column(name = "TEST-SOME-OTHER-STUFF")
    private String testSomeOtherStuff;

    public Optional<String> getTestSomeOtherStuff() {
        return Optional.ofNullable(testSomeOtherStuff);
    }

    public void setTestSomeOtherStuff(String testSomeOtherStuff) {
        this.testSomeOtherStuff = testSomeOtherStuff;
    }
}
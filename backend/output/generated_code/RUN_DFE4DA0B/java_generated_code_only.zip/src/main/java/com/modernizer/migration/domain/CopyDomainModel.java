package com.modernizer.migration.domain;

import java.util.Optional;
public class CopyDomainModel {
    private String testSomeOtherStuff;

    public CopyDomainModel(String testSomeOtherStuff) {
        this.testSomeOtherStuff = testSomeOtherStuff;
    }

    // Getters and setters
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.math.BigDecimal;

@Entity
public class Group1Item2 {

    @Column(name = "ITEM-1")
    private BigDecimal item1;

    public BigDecimal getItem1() {
        return item1;
    }

    public void setItem1(BigDecimal item1) {
        this.item1 = item1;
    }
}

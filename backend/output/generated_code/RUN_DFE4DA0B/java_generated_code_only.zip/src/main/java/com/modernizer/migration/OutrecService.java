package com.modernizer.migration;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Optional;

public class OutrecService {

    @Inject
    private OutrecRepository outrecRepository;

    public Optional<OutrecDTO> getOutrecData() {
        // Migrated from: OUTREC.CBL:05 OUT-FIELD-1 PIC X(5).
        return outrecRepository.getOutrecData();
    }

    public void saveOutrecData(OutrecDTO outrecDTO) {
        // Migrated from: OUTREC.CBL:COPY OUTREC2.
        outrecRepository.saveOutrecData(outrecDTO);
    }
}

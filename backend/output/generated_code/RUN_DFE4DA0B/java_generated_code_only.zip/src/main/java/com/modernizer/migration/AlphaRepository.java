package com.modernizer.migration;

import java.util.List;

public class AlphaRepository {

    public HttpResponse handleExpectStatements() {
        // TO DO: implement business logic for EXPECT statements
        return HttpResponse.ok().build();
    }
}

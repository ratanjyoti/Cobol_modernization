package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class OutField2Service {

    @Column(name = "OUT-FIELD-2", length = 16)
    private String outField2;

    public Optional<String> getOutField2() {
        return Optional.ofNullable(outField2);
    }

    public void setOutField2(String outField2) {
        this.outField2 = outField2;
    }
}

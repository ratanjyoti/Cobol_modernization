package com.modernizer.migration;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class Mixed003Item1 {

    private String mixed003Item1;

    @Inject
    public void setMixed003Item1(String mixed003Item1) {
        this.mixed003Item1 = mixed003Item1;
    }

    public String getMixed003Item1() {
        return mixed003Item1;
    }
}
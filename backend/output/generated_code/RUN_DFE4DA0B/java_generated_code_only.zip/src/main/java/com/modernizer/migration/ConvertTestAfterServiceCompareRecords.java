package com.modernizer.migration.ConvertTestAfterService;

import io.quarkus.hibernate.orm.annotation.Entity;
import io.quarkus.hibernate.orm.annotation.Id;
import java.util.List;

@Entity
public class ConvertTestAfterServiceCompareRecords {

    @Id
    private String expectedResultFilename;

    public void compareRecords() {
        // TO DO: implement record comparison logic
    }
}

package com.modernizer.migration.exception;

import javax.inject.Singleton;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class CopyException extends Exception {
    private static final long serialVersionUID = 1L;

    public CopyException(String message) {
        super(message);
    }
}

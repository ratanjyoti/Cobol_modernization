package com.modernizer.migration;

import java.util.List;

public class AlphaTable2 {

    private String wsThing3;
    private String wsThing4;

    public AlphaTable2(String wsThing3, String wsThing4) {
        this.wsThing3 = wsThing3;
        this.wsThing4 = wsThing4;
    }

    public String getWsThing3() {
        return wsThing3;
    }

    public void setWsThing3(String wsThing3) {
        this.wsThing3 = wsThing3;
    }

    public String getWsThing4() {
        return wsThing4;
    }

    public void setWsThing4(String wsThing4) {
        this.wsThing4 = wsThing4;
    }
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotation.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Copy006Item1 {

    @Column(name = "COPY006-ITEM-1")
    private String copy006Item1;

    public Optional<String> getCopy006Item1() {
        return Optional.ofNullable(copy006Item1);
    }

    public void setCopy006Item1(String copy006Item1) {
        this.copy006Item1 = copy006Item1;
    }
}

package com.modernizer.migration;

public class FileMockAfterDTO {

    private String utTestCaseName;

    public void utBefore() {
        // TO DO: implement utBefore method
    }

    public void utAfter() {
        // TO DO: implement utAfter method
    }

    public void utInitialize() {
        // TO DO: implement utInitialize method
    }

    public void end() {
        // TO DO: implement end method
    }
}
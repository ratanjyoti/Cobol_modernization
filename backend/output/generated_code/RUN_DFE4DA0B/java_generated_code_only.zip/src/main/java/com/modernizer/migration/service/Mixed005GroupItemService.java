package com.modernizer.migration.service;

import javax.inject.Inject;
import javax.inject.Singleton;

public class Mixed005GroupItemService {

    @Inject
    private Mixed006Adapter mixed006Adapter;

    public void handleMixed005GroupItemCall() {
        // Migrated from: mixed005-padded.CBL::{source_location}
        // Handle the call to mixed006.CBL
        mixed006Adapter.call();
    }
}

package com.modernizer.migration.dto;

public class Mixed005GroupItemDto {

    private BigDecimal mixed005GroupItemId;
    private String mixed005GroupName;
    // Migrated from: mixed005-padded.CBL::{source_location}
    // Define the data model for mixed005 group item
}


package com.modernizer.migration.domain.service;

import io.quarkus.hibernate.orm.annotation.Entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Optional;

@Entity
public class ReturncodeService {
    @Id
    private String value1;
    @Id
    private String value2;

    public void makeCall(String arg1, String arg2) {
        this.value1 = arg1;
        this.value2 = arg2;
        // Invoke PROG1 program
        // TODO: Implement adapter stub for EXTERNAL_SERVICE
        System.out.println("Invoked PROG1 with args: " + arg1 + " and " + arg2);
    }
}

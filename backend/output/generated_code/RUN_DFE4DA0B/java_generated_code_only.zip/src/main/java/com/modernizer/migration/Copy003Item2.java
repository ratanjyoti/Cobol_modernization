package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Copy003Item2 {

    @Column(name = "COPY003-ITEM-2")
    private String copy003Item2;

    public Optional<String> getCopy003Item2() {
        return Optional.ofNullable(copy003Item2);
    }

    public void setCopy003Item2(String copy003Item2) {
        this.copy003Item2 = copy003Item2;
    }
}
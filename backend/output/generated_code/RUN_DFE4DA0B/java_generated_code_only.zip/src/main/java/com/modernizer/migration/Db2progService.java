package com.modernizer.migration;

import javax.inject.Inject;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class Db2progService {

    private final DataSource dataSource;

    @Inject
    public Db2progService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void main() {
        // TO DO: implement business logic for DB2 instructions
    }

    public void select() {
        // TO DO: implement SELECT statement for DB2 instructions
    }

    public void openCursor() {
        // TO DO: implement OPEN-CURSOR instruction
    }

    public void fetchSql() {
        // TO DO: implement FETCH SQL statement
    }

    public void closeCursor() {
        // TO DO: implement CLOSE-CURSOR instruction
    }
}
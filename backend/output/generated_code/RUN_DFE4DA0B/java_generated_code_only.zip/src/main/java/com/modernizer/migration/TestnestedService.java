package com.modernizer.migration;

import javax.inject.Singleton;
import java.util.Optional;

@Singleton
public class TestnestedService {

    private final String oneDigit;

    public TestnestedService() {
        this.oneDigit = "ONE-DIGIT";
    }

    public void endEvaluate() {
        if (oneDigit.equals("1")) {
            oneDigit = "2";
        } else {
            oneDigit = "5";
        }
    }

    public String getOneDigit() {
        return oneDigit;
    }
}

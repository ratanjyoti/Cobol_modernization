package com.modernizer.migration;

public class Db2progDomain {

    private String firstName;
    private String lastName;
    private String tmsCreat;

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setTmsCreat(String tmsCreat) {
        this.tmsCreat = tmsCreat;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getTmsCreat() {
        return tmsCreat;
    }
}
package com.modernizer.migration;

import javax.inject.Singleton;
import java.util.Optional;

@Singleton
public class MinimalBeforeService {

    public void speak() {
        String wsMessageType = "GREETING";
        if (wsMessageType.equals("GREETING")) {
            wsMessage = "HELLO, WORLD!";
        } else if (wsMessageType.equals("FAREWELL")) {
            wsMessage = "SEE YOU LATER, ALLIGATOR!";
        }
    }

    private String wsMessage;

    public void end() {
        // No logic here
    }
}

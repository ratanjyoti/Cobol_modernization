package com.modernizer.migration.dto;

import java.util.Optional;
public class CopyDTO {
    private String testSomeOtherStuff;

    public CopyDTO(String testSomeOtherStuff) {
        this.testSomeOtherStuff = testSomeOtherStuff;
    }

    // Getters and setters
}

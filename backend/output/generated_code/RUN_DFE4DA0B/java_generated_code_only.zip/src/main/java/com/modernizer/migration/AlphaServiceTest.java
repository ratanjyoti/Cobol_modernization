package com.modernizer.migration;

import io.quarkus.test.junit.QuarkusTest;
import org.junit.jupiter.api.Test;

@QuarkusTest
public class AlphaServiceTest {

    @Inject
    private AlphaService alphaService;

    @Test
    public void testHandleExpectStatements() {
        // TO DO: implement test for handleExpectStatements method
    }
}

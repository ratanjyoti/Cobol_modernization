package com.modernizer.migration.greeting;

import javax.inject.Singleton;
import java.util.Optional;

@Singleton
public class GreetingService {

    public String handleGreetingMessage(String wsFriend, String messageIsGreeting, String messageIsFarewell, String messageIsFarewellLong) {
        if (messageIsGreeting && wsFriend.equals(" ")) {
            return "World";
        } else if (messageIsGreeting && !wsFriend.equals(" ")) {
            return wsFriend;
        } else if (messageIsFarewell && wsFriend.equals(" ")) {
            return "alligator!";
        } else if (messageIsFarewell && !wsFriend.equals(" ")) {
            return wsFriend;
        } else if (messageIsFarewellLong && wsFriend.equals(" ")) {
            return :TEXT:;
        } else if (messageIsFarewellLong && !wsFriend.equals(" ")) {
            return wsFriend;
        }
        throw new RuntimeException("Invalid input");
    }
}

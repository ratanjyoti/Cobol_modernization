package com.modernizer.migration.greeting;

import javax.inject.Singleton;
import java.util.Optional;

@Singleton
public class GreetingRepository {

    public String handleGreetingMessage(GreetingService greetingService, String wsFriend, String messageIsGreeting, String messageIsFarewell, String messageIsFarewellLong) {
        return greetingService.handleGreetingMessage(wsFriend, messageIsGreeting, messageIsFarewell, messageIsFarewellLong);
    }
}

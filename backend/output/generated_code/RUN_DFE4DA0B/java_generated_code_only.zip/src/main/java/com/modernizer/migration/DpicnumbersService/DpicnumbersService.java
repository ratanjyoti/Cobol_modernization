package com.modernizer.migration.DpicnumbersService;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.math.BigDecimal;

@Entity
public class DpicnumbersService {

    @Column(name = "VALUE-1")
    private BigDecimal value1;

    @Column(name = "VALUE-2")
    private BigDecimal value2;

    public void assign() {
        this.value1 = BigDecimal.valueOf(10);
    }

    public void end() {
        // End of program execution
    }
}

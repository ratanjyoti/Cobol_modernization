package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import java.util.Optional;

@Entity
public class Group1Item2Item22 {

    private String item21_2;

    public Group1Item2Item22() {}

    public Optional<String> getItem21_2() {
        return Optional.ofNullable(item21_2);
    }

    public void setItem21_2(String item21_2) {
        this.item21_2 = item21_2;
    }
}
package com.modernizer.migration;

import java.util.List;

public class AlphaTable1 {

    private String wsThing1;
    private String wsThing2;

    public AlphaTable1(String wsThing1, String wsThing2) {
        this.wsThing1 = wsThing1;
        this.wsThing2 = wsThing2;
    }

    public String getWsThing1() {
        return wsThing1;
    }

    public void setWsThing1(String wsThing1) {
        this.wsThing1 = wsThing1;
    }

    public String getWsThing2() {
        return wsThing2;
    }

    public void setWsThing2(String wsThing2) {
        this.wsThing2 = wsThing2;
    }
}

package com.modernizer.migration;

public class Db2progException extends Exception {

    public Db2progException(String message) {
        super(message);
    }
}
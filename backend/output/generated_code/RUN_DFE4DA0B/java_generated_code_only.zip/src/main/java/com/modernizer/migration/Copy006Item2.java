package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotation.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Copy006Item2 {

    @Column(name = "COPY006-ITEM-2")
    private String copy006Item2;

    public Optional<String> getCopy006Item2() {
        return Optional.ofNullable(copy006Item2);
    }

    public void setCopy006Item2(String copy006Item2) {
        this.copy006Item2 = copy006Item2;
    }
}

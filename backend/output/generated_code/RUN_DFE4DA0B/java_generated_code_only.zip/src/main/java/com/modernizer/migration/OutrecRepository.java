package com.modernizer.migration;

import javax.inject.Inject;
import java.util.Optional;

public class OutrecRepository {

    @Inject
    private OutrecService outrecService;

    public Optional<OutrecDTO> getOutrecData() {
        // Migrated from: OUTREC.CBL:05 OUT-FIELD-1 PIC X(5).
        return outrecService.getOutrecData();
    }

    public void saveOutrecData(OutrecDTO outrecDTO) {
        // Migrated from: OUTREC.CBL:COPY OUTREC2.
        outrecService.saveOutrecData(outrecDTO);
    }
}

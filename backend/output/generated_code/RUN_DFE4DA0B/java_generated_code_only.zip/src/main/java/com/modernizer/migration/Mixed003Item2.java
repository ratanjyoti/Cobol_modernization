package com.modernizer.migration;

import javax.inject.Inject;
import javax.inject.Singleton;

@Singleton
public class Mixed003Item2 {

    private String mixed003Item2;

    @Inject
    public void setMixed003Item2(String mixed003Item2) {
        this.mixed003Item2 = mixed003Item2;
    }

    public String getMixed003Item2() {
        return mixed003Item2;
    }
}
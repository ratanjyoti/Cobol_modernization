package com.modernizer.migration;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AlphaTable2Test {

    @Test
    public void testGetWsThing3() {
        // TO DO: implement test for getWsThing3 method
    }

    @Test
    public void testSetWsThing3() {
        // TO DO: implement test for setWsThing3 method
    }
}

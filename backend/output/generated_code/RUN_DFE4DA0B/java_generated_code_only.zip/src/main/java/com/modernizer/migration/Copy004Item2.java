package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Copy004Item2 {

    @Column(name = "COPY004-ITEM-2")
    private String copy004Item2;

    public Optional<String> getCopy004Item2() {
        return Optional.ofNullable(copy004Item2);
    }

    public void setCopy004Item2(String copy004Item2) {
        this.copy004Item2 = copy004Item2;
    }
}
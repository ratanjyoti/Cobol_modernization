package com.modernizer.migration.Replace3Service;

public class UtGamma {
    private String utGamma;

    public UtGamma() {
        this.utGamma = "Gamma";
    }

    public String getUtGamma() {
        return utGamma;
    }
}
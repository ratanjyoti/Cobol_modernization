package com.modernizer.migration;

public class AlphaDTO {

    private String wsField1;
    private String wsField2;
    private List<AlphaTable1> wsTable1;
    private List<AlphaTable2> wsTable2;

    public AlphaDTO(String wsField1, String wsField2) {
        this.wsField1 = wsField1;
        this.wsField2 = wsField2;
    }

    public List<AlphaTable1> getWsTable1() {
        return wsTable1;
    }

    public void setWsTable1(List<AlphaTable1> wsTable1) {
        this.wsTable1 = wsTable1;
    }

    public String getWsField1() {
        return wsField1;
    }

    public void setWsField1(String wsField1) {
        this.wsField1 = wsField1;
    }

    public String getWsField2() {
        return wsField2;
    }

    public void setWsField2(String wsField2) {
        this.wsField2 = wsField2;
    }
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UtMockDynamicCallService {

    @Id
    private String wsAlpha;
    private String wsOmega;

    public void dynamicCall() {
        // TO DO: implement dynamic call logic
    }

    public void end() {
        // TO DO: implement end logic
    }
}
package com.modernizer.migration;

import javax.inject.Inject;
import javax enterprise.ejb.EJBContext;
import java.util.Optional;

public class Mixed006Item1 {

    private final EJBContext ejbContext;

    @Inject
    public Mixed006Item1(EJBContext ejbContext) {
        this.ejbContext = ejbContext;
    }

    public String getMixed006Item1() {
        return mixed006Item1;
    }

    private String mixed006Item1;

    public void setMixed006Item1(String mixed006Item1) {
        this.mixed006Item1 = mixed006Item1;
    }
}
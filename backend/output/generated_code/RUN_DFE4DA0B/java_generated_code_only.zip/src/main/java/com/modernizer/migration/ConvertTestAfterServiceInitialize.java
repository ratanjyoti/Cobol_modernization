package com.modernizer.migration.ConvertTestAfterService;

import io.quarkus.hibernate.orm.annotation.Entity;
import io.quarkus.hibernate.orm.annotation.Id;
import java.util.List;

@Entity
public class ConvertTestAfterServiceInitialize {

    @Id
    private String args;

    public void initialize(String[] args) {
        this.args = Arrays.asList(args);
    }
}

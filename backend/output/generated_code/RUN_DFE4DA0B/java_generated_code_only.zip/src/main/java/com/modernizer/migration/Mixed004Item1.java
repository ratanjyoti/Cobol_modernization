package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Mixed004Item1 {

    @Column(name = "MIXED004-ITEM-1")
    private String mixed004Item1;

    public Optional<String> getMixed004Item1() {
        return Optional.ofNullable(mixed004Item1);
    }

    public void setMixed004Item1(String mixed004Item1) {
        this.mixed004Item1 = mixed004Item1;
    }
}

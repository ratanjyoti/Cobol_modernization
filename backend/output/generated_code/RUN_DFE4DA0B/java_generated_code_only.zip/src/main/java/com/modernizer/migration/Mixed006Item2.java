package com.modernizer.migration;

import javax.inject.Inject;
import javax.enterprise.ejb.EJBContext;
import java.util.Optional;

public class Mixed006Item2 {

    private final EJBContext ejbContext;

    @Inject
    public Mixed006Item2(EJBContext ejbContext) {
        this.ejbContext = ejbContext;
    }

    public String getMixed006Item2() {
        return mixed006Item2;
    }

    private String mixed006Item2;

    public void setMixed006Item2(String mixed006Item2) {
        this.mixed006Item2 = mixed006Item2;
    }
}
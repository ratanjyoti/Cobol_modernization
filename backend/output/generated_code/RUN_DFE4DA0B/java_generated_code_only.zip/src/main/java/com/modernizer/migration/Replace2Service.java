package com.modernizer.migration.Replace2Service;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.Optional;

@Singleton
public class Replace2Service {
    @Inject
    private String wsGamma;
    @Inject
    private String wsOmega;
    @Inject
    private String wsSubprogramName;

    public void dynamicCall() {
        // TO DO: implement dynamic call logic
    }

    public void end() {
        // TO DO: implement end logic
    }
}

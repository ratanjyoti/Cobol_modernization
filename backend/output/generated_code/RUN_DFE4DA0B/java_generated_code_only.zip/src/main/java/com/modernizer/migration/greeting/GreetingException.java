package com.modernizer.migration.greeting;

public class GreetingException extends RuntimeException {

    public GreetingException(String message) {
        super(message);
    }
}

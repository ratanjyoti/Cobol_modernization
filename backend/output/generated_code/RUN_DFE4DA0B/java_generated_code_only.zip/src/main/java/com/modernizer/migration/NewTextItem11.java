package com.modernizer.migration;

import javax.inject.Inject;
import javax.inject.Named;
import java.util.Optional;

public class NewTextItem11 {
    @Inject
    private Optional<String> optionalString;

    public String newTextItem11() {
        return optionalString.orElse("Default value");
    }
}
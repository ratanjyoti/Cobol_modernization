package com.modernizer.migration;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AlphaDomainModelTest {

    @Test
    public void testGetWsDisplayNumeric() {
        // TO DO: implement test for getWsDisplayNumeric method
    }

    @Test
    public void testSetWsDisplayNumeric() {
        // TO DO: implement test for setWsDisplayNumeric method
    }
}

package com.modernizer.migration;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AlphaTable1Test {

    @Test
    public void testGetWsThing1() {
        // TO DO: implement test for getWsThing1 method
    }

    @Test
    public void testSetWsThing1() {
        // TO DO: implement test for setWsThing1 method
    }
}

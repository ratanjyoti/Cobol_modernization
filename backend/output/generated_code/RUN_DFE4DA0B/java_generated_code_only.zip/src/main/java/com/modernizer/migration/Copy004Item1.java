package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Copy004Item1 {

    @Column(name = "COPY004-ITEM-1")
    private String copy004Item1;

    public Optional<String> getCopy004Item1() {
        return Optional.ofNullable(copy004Item1);
    }

    public void setCopy004Item1(String copy004Item1) {
        this.copy004Item1 = copy004Item1;
    }
}
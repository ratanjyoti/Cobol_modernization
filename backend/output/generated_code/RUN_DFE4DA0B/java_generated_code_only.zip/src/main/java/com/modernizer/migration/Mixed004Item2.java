package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Mixed004Item2 {

    @Column(name = "MIXED004-ITEM-2")
    private String mixed004Item2;

    public Optional<String> getMixed004Item2() {
        return Optional.ofNullable(mixed004Item2);
    }

    public void setMixed004Item2(String mixed004Item2) {
        this.mixed004Item2 = mixed004Item2;
    }
}

package com.modernizer.migration;

import io.quarkus.hibernate.orm.annotations.Entity;
import javax.persistence.Column;
import java.util.Optional;

@Entity
public class Copy003Item1 {

    @Column(name = "COPY003-ITEM-1")
    private String copy003Item1;

    public Optional<String> getCopy003Item1() {
        return Optional.ofNullable(copy003Item1);
    }

    public void setCopy003Item1(String copy003Item1) {
        this.copy003Item1 = copy003Item1;
    }
}
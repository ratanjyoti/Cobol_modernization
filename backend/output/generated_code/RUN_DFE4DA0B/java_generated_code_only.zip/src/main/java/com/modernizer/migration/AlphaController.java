package com.modernizer.migration;

import io.quarkus.http.HttpResponse;
import io.quarkus.http.annotation.Route;
import javax.inject.Inject;
import java.util.List;

public class AlphaController {

    @Inject
    private AlphaService alphaService;

    @Route(path = "expect-statements")
    public HttpResponse handleExpectStatements() {
        // TO DO: implement business logic for EXPECT statements
        return HttpResponse.ok().build();
    }
}
